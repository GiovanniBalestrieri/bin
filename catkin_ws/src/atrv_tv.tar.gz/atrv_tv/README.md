Per compilare è necessario avere installato player 

Per eseguirlo è necessario avere

ros-indigo-navigation
ros-indigo-gmapping
ros-indigo-joystick-drivers


